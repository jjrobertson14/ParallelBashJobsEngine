#!/bin/bash

grep g ../input/sample.txt > /dev/null
echo "grepped 1 time"
grep g ../input/sample.txt > /dev/null
echo "grepped 2 time"
grep g ../input/sample.txt > /dev/null
echo "grepped 3 time"
grep g ../input/sample.txt > /dev/null
echo "grepped 4 time"
grep g ../input/sample.txt > /dev/null
echo "grepped 5 time"
grep g ../input/sample.txt > /dev/null
echo "grepped 6 time"
grep g ../input/sample.txt > /dev/null
echo "grepped 7 times"
echo "Done!"