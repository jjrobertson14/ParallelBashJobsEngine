#!/bin/bash
set -e

cat fakie
echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt > ../output/g-to-fox-sample-1.txt && echo ran sed 1 time"
echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt > ../output/g-to-fox-sample-2.txt && echo ran sed 2 times"
echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt > ../output/g-to-fox-sample-3.txt && echo ran sed 3 times"
echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt > ../output/g-to-fox-sample-4.txt && echo ran sed 4 times"
echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt > ../output/g-to-fox-sample-5.txt && echo ran sed 5 times"
echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt > ../output/g-to-fox-sample-6.txt && echo ran sed 6 times"
echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt > ../output/g-to-fox-sample-7.txt && echo ran sed 7 times"
# echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt"
# echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt"
# echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt"
# echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt"
# echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt"
# echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt"
# echo "_-_-_COMMAND-sed -n 's/g/fox/p' ../input/sample.txt"