#!/bin/bash

sed -n 's/g/fox/p' ../input/sample.txt > ../input/g-to-fox-sample.txt
echo "sedded 1 time"
sed -n 's/g/fox/p' ../input/sample.txt > ../input/g-to-fox-sample.txt
echo "sedded 2 times"
sed -n 's/g/fox/p' ../input/sample.txt > ../input/g-to-fox-sample.txt
echo "sedded 3 times"
sed -n 's/g/fox/p' ../input/sample.txt > ../input/g-to-fox-sample.txt
echo "sedded 4 times"
sed -n 's/g/fox/p' ../input/sample.txt > ../input/g-to-fox-sample.txt
echo "sedded 5 times"
sed -n 's/g/fox/p' ../input/sample.txt > ../input/g-to-fox-sample.txt
echo "sedded 6 times"
sed -n 's/g/fox/p' ../input/sample.txt > ../input/g-to-fox-sample.txt
echo "sedded 7 times"